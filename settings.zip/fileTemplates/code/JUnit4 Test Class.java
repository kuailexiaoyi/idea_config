import static org.junit.Assert.*;
import static org.junit.Assume.*;
import static org.mockito.Mockito.*;
import static org.mockito.Matchers.*;
#parse("File Header.java")
public class ${NAME} {
  ${BODY}
}