#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
* @Title:  ${file_name}
* @Description  ${DESCRIPTION}
* @Package ${package_name}
* @author  曾 睿
* @date  ${YEAR}-${MONTH}-${DAY}
* @Version V1.0
**/
public interface ${NAME} {
}
